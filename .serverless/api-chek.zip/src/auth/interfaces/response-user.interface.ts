import { User } from './user.interface';

export interface ResponseUser {
  user: User;
  token: string;
}
